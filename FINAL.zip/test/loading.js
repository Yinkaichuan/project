$(document).ready(function () {
  setTimeout(function () {
    $(".loading-color").fadeOut(500);
  },1000);
});



 



