
<?php
// 啟動 session
session_start();

// 建立數據庫連接
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連接是否成功
if ($conn->connect_error) {
    die("連接失敗：" . $conn->connect_error);
}

// 每頁顯示的結果數量
$resultsPerPage =6;

// 第一階段：執行搜尋
if (isset($_GET['searchSubmit'])) {
    // 檢查 "search" 是否存在
    $searchKeyword = isset($_GET['search']) ? $_GET['search'] : '';

    // 構建 SQL 查詢
    $sql = "SELECT * FROM music_info WHERE title LIKE '%$searchKeyword%'";

    // 執行查詢
    $result = $conn->query($sql);

    // 存儲搜尋結果到 session
    $_SESSION['searchResults'] = [];

    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION['searchResults'][] = $row;
        }

        // 顯示分頁結果
        $totalResults = count($_SESSION['searchResults']);
        $totalPages = ceil($totalResults / $resultsPerPage);

        // 當前頁碼
        $currentPage = isset($_GET['page']) ? $_GET['page'] : 1;
        $start = ($currentPage - 1) * $resultsPerPage;
        for ($i = $start; $i < $start + $resultsPerPage; $i++) {
            if (isset($_SESSION['searchResults'][$i])) {
                $row = $_SESSION['searchResults'][$i];
        
                // 生成 YouTube iframe 代碼
                $iframeCode = '<iframe width="560" height="315" src="https://www.youtube.com/embed/' . $row["youtube_id"] . '" frameborder="0" allowfullscreen></iframe>';
                
                echo '<div class="nominee">';
                echo '<div class="iframe-container">' . $iframeCode . "<br>" . '</div>';
                echo '<h2>' . $row["id"] . ' - Name: ' . $row["title"] . '</h2>';
                echo '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.';
                
                echo '<span class="more">aaaa</span>';
                echo '</p>';
                echo '<button class="read-more-btn">Read more</button>';

                echo '<div class="overlay">';
                
              
                echo '<div class="pop">';//模態視窗test 無用
                echo '<div class="modal">';
                echo '<div class="popup">' . $iframeCode . "<br>" . '</div>';
                echo '<h4>' . $row["id"] . ' - Name: ' . $row["title"] . '</h4>';
                echo '<span class="x" draggable="true">&times;</span>';
                echo '</div>';
                echo '</div>';

                echo '</div>';
                echo '</div>';

                
            }
            
                
        }
/*
        // 備份
        for ($i = $start; $i < $start + $resultsPerPage; $i++) {
            if (isset($_SESSION['searchResults'][$i])) {
                $row = $_SESSION['searchResults'][$i];

                // 生成 YouTube iframe 代碼
                $iframeCode = '<iframe width="560" height="315" src="https://www.youtube.com/embed/' . $row["youtube_id"] . '" frameborder="0" allowfullscreen></iframe>';

                echo '<div class="nominee">';
                echo '<div class="iframe-container">'.$iframeCode . "<br>".'</div>';
                echo '<h2>' . $row["id"] . ' - Name: ' . $row["title"] . '</div>';
                
                
            }
        }
*/        
        echo '<div class="page">';
        echo '<div class="pagination">'; // 將頁碼置中的容器開始

        for ($page = 1; $page <= $totalPages; $page++) {
        echo "<a href='?searchSubmit&page=$page'>$page</a> ";
        }

        echo '</div>'; // 將頁碼置中的容器結束

    } else {
        echo "沒有匹配的搜尋結果";
    }
}

// 第二階段：選擇特定類型過濾
if (isset($_GET['filter'])) {
    // 接收表單提交的過濾類型
    $filterKeyword = $_GET['filter'];

    // 如果有搜尋結果，則進行過濾
    if (!empty($_SESSION['searchResults'])) {
        $filteredResults = [];
        foreach ($_SESSION['searchResults'] as $row) {
            if ($row['title'] == $filterKeyword) {
                $filteredResults[] = $row;
            }
        }
        // 顯示分頁結果
        if (!empty($filteredResults)) {
            $totalResults = count($filteredResults);
            $totalPages = ceil($totalResults / $resultsPerPage);

            // 當前頁碼
            $currentPage = isset($_GET['page']) ? $_GET['page'] : 1;
            $start = ($currentPage - 1) * $resultsPerPage;

            // 顯示當前頁的結果
            for ($i = $start; $i < $start + $resultsPerPage; $i++) {
                if (isset($filteredResults[$i])) {
                    $row = $filteredResults[$i];

                    $iframeCode = '<iframe width="560" height="315" src="https://www.youtube.com/embed/' . $row["youtube_id"] . '" frameborder="0" allowfullscreen></iframe>';
                        echo '<div class="nominee">';
                        echo '<div class="iframe-container">' . $iframeCode . "<br>" . '</div>';
                        echo '<h2>' . $row["id"] . ' - Name: ' . $row["title"] . '</h2>';
                        echo '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.';
                        echo '<span class="more">aaaa</span>';
                        echo '</p>';
                        echo '<button class="read-more-btn">Read more</button>';
                        echo '<div class="overlay">';
                        echo '<div class="pop">';//模態視窗test 無用
                        echo '<div class="modal">';
                        echo '<div class="popup">' . $iframeCode . "<br>" . '</div>';
                        echo '<h4>' . $row["id"] . ' - Name: ' . $row["title"] . '</h4>';
                        echo '<span class="x" draggable="true">&times;</span>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                    }       
                        
                }  
                echo '<div class="page">';
                echo '<div class="pagination">';
 

            // 顯示分頁連結
            for ($page = 1; $page <= $totalPages; $page++) {
                echo "<a href='?filter=$filterKeyword&page=$page'>$page</a> ";
            }



        } 
        else {
            echo "沒有匹配的過濾結果";
        }
    } else {
        echo "沒有搜尋結果，無法進行過濾";
    }
}

// 關閉數據庫連接
$conn->close();
?>
