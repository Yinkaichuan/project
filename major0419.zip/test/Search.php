<?php
// 啟動 session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>桃園客家文化館導覽網站</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="loading.js"></script>
    <script src="page.js"></script>
    <link rel="stylesheet" href ="CSS/Searchstyle.css?v=<?=time()?>">
	  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> <!--icon連結的css-->
</head>
<body style="margin: 0;padding: 0;">
<header>
        <button class="menu" id="mobile-menu">&#9776;</button>
        <a href ="index.php" class="title1">桃園客家文化館導覽網站</a>
        <nav class="navbar">
            <ul class="menu-list"> 
                <li><a href="index.php"><span>回首頁</span></a></li>
                <li><a href="virtual tour.php"><span>虛擬導覽</span></a></li>
                <li><a href="Search.php"><span>音樂作品查詢</span></a></li>
                <li><a href="#"><span>問卷回饋</span></a></li>
            </ul>
        </nav>
    </header>


    <main>
   <div class="big"></div>
   <a class="gotop"  id="backToTopBtn" href="#">
    <img src="https://campus-xoops.tn.edu.tw/uploads/top.png" style="width: 64px; z-index: 2300; position: fixed; right: 20px; bottom: 175px;" alt="#" title="點我回到上方">
    </a>
    <nav class=search>
     <ul>
    <br></br>
    <!-- 搜尋表單 -->
<form action="" method="GET">
   <select class="dropdown" name="searchType" id="option-select">
    <option value="option1">關鍵字</option>
    <option value="song">歌名</option>
    <option value="artist">歌手</option>
   </select>

    <label for="search">搜尋歌曲：</label>
    <input type="text" name="search" id="search"  placeholder="輸入關鍵字">
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="searchSubmit"><i class="fa fa-search" aria-hidden="true"></i></button>
</form>
     </ul>
    </nav>
<div class="selectbutton">
  <form id="filterForm" action="" method="GET" >
  <label for="type">種類：</label>
    <!--<button class="button-31" onclick="changeColorAndSubmit(this)" type="submit" name="searchSubmit">全部</button>-->
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="filter" value="現代流行曲">現代流行曲</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="filter" value="客家傳統音樂">客家傳統音樂</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="filter" value="器樂曲">器樂曲</button>
  </form>
  
  <form id="filterForm" action="" method="GET">
  <label for="type">風格：</label>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="男女對唱情歌">男女對唱情歌</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="抒情">抒情</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="平板調">平板調</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="山歌子">山歌子</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="客家八音">客家八音</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="空弦演奏">空弦演奏</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="爵士">爵士</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="老山歌">老山歌</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="鄉村">鄉村</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="管樂">管樂</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="九腔十八調">九腔十八調</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="搖滾">搖滾</button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="民謠">民謠</button>
  </form>
    


</div>
<br></br>

 <div class="sqloput">
 
    <?php
        // 引入外部的 PHP 文件
        include 'PHP/Search.php';
    ?>
 </div>
 
    </main>
	
    <div class="footer">
    <footer>
        Pitohui © All Rights Reserved. | Designed by GGlisten X Cadiis
    </footer>
    </div>
    <script>
  $(function() {
    function checkWindowSize() {
      if ($(window).width() < 768) {
        $('.menu-list').css('max-height', '0');
        $('#mobile-menu').off('click').on('click', function () {
          // 切換 max-height 的值來實現過渡效果
          $('.menu-list').css('max-height', function() {
            return $(this).css('max-height') === '0px' ? $(this).prop('scrollHeight') + 'px' : '0';
          });
        });
      } else {
        $('.menu-list').css('max-height', 'none'); // 移除 max-height，讓內容自動撐開
        // 可能需要處理其他邏輯
      }
    }
    // 初始檢查
    checkWindowSize();
    // 視窗大小改變時重新檢查
    $(window).resize(checkWindowSize);
  });

</script>

<script>
// 等待DOM内容加载完成后执行
 document.addEventListener("DOMContentLoaded", function() {
  // 选择所有的读取更多按钮
  var readMoreBtns = document.querySelectorAll(".read-more-btn");
  // 为每个按钮添加点击事件监听器
  readMoreBtns.forEach(function(btn) {
    btn.addEventListener("click", function() {
      // 找到同一个父元素下的.more元素
      // 假设.more元素是按钮的兄弟元素，可以根据实际情况调整
      var moreText = this.parentNode.querySelector(".more");

      // 切换文本显示状态
      if (moreText.style.display === "none" || !moreText.style.display) {
        moreText.style.display = "inline";
        this.textContent = "Read less"; // 更改按钮的文本
      } else {
        moreText.style.display = "none";
        this.textContent = "Read more"; // 恢复按钮的文本
      }
    });
  });
});

</script>




</body>
<!--隱藏加載-->
</html>