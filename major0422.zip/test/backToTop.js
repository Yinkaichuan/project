// 當用戶滾動下去100px時，顯示圖片
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    document.getElementById("backToTopBtn").style.display = "block";
  } else {
    document.getElementById("backToTopBtn").style.display = "none";
  }
}

$(document).ready(function(){
    // 當按鈕被點擊時
    $("#backToTopBtn").click(function(event) {
      event.preventDefault();
      // 平滑滾動到頁面頂部
      $("html, body").animate({ scrollTop: 0 }, "slow");
      return false;
    });
  });
  
