<?php
// 啟動 session
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>桃園客家文化館導覽網站</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="loading.js"></script>
    <script src="page.js"></script>
    <script src="backToTop.js"></script>
    <link rel="stylesheet" href ="CSS/Searchstyle.css?v=<?=time()?>">
	  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> <!--icon連結的css-->
</head>
<body style="margin: 0;padding: 0;">
<header>
        <button class="menu" id="mobile-menu">&#9776;</button>
        <a href ="index.php" class="title1">桃園客家文化館導覽網站</a>
        <nav class="navbar">
            <ul class="menu-list"> 
                <li><a href="index.php"><span>回首頁</span></a></li>
                <li><a href="virtual tour.php"><span>虛擬導覽</span></a></li>
                <li><a href="Search.php"><span>音樂作品查詢</span></a></li>
                <li><a href="#"><span>問卷回饋</span></a></li>
            </ul>
        </nav>
</header>


    <main>
   <div class="big"></div>
   <a class="gotop" id="backToTopBtn" href="#">
    <img src="https://campus-xoops.tn.edu.tw/uploads/top.png" style="width: 64px; z-index: 100; position: fixed; right: 20px; bottom: 175px;" alt="#" title="點我回到上方">
    </a>
    <nav class=search>
     <ul>
    <br></br>
    <!-- 搜尋表單 -->
<form  action="" method="GET">
  
   <select class="dropdown" name="searchType" id="option-select">
    <option value="option1">關鍵字</option>
    <option value="song">歌名</option>
    <option value="artist">歌手</option>
   </select>
    <label for="search" class="searchlb">搜尋歌曲：</label>
    <input type="text" name="search" id="search"  placeholder="輸入關鍵字">
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="searchSubmit"><i class="fa fa-search" aria-hidden="true"></i></button>

</form>
     </ul>
    </nav>
<div class="selectbutton">
  <label class="filterbt">種類：</label>
  <form class="filterbutton" id="filterForm" action="" method="GET" >
    
    <!--<button class="button-31" onclick="changeColorAndSubmit(this)" type="submit" name="searchSubmit">全部</button>-->
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="filter" value="現代流行曲"><h4>現代流行曲</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="filter" value="客家傳統音樂"><h4>客家傳統音樂</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="filter" value="器樂曲"><h4>器樂曲</h4></button>
  </form>

  

  <div class="scroll-container">
   <label class="styletext">風格：</label>
  <form id="filterForm" action="" method="GET" class="nav">
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="男女對唱情歌"><h4>男女對唱情歌</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="抒情"><h4>抒情</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="平板調"><h4>平板調</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="山歌子"><h4>山歌子</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="客家八音"><h4>客家八音</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="空弦演奏"><h4>空弦演奏</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="爵士"><h4>爵士</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="老山歌"><h4>老山歌</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="鄉村"><h4>鄉村</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="管樂"><h4>管樂</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="九腔十八調">九腔十八調</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="搖滾"><h4>搖滾</h4></button>
    <button class="category-button" onclick="changeColorAndSubmit(this)" type="submit" name="style" value="民謠"><h4>民謠</h4></button>
  </form>
  
  </div>
<button class="scroll-button prev">&laquo;</button>
  <button class="scroll-button next">&raquo;</button>
</div>
<br></br>

 <div class="sqloput">
 
    <?php
        // 引入外部的 PHP 文件
        include 'PHP/Search.php';
    ?>
 </div>
 
    </main>
	
    <div class="footer">
    <footer>
        Pitohui © All Rights Reserved. | Designed by GGlisten X Cadiis
    </footer>
    </div>
<script>
  $(function() {
    function checkWindowSize() {
      if ($(window).width() < 768) {
        $('.menu-list').css('max-height', '0');
        $('#mobile-menu').off('click').on('click', function () {
          // 切換 max-height 的值來實現過渡效果
          $('.menu-list').css('max-height', function() {
            return $(this).css('max-height') === '0px' ? $(this).prop('scrollHeight') + 'px' : '0';
          });
        });
      } else {
        $('.menu-list').css('max-height', 'none'); // 移除 max-height，讓內容自動撐開
        // 可能需要處理其他邏輯
      }
    }
    // 初始檢查
    checkWindowSize();
    // 視窗大小改變時重新檢查
    $(window).resize(checkWindowSize);
  });

</script>

<script>
 // 等待DOM内容加载完成后执行
 document.addEventListener("DOMContentLoaded", function() {
  // 选择所有的读取更多按钮
  var readMoreBtns = document.querySelectorAll(".read-more-btn");
  // 为每个按钮添加点击事件监听器
  readMoreBtns.forEach(function(btn) {
    btn.addEventListener("click", function() {
      // 找到同一个父元素下的.more元素
      // 假设.more元素是按钮的兄弟元素，可以根据实际情况调整
      var moreText = this.parentNode.querySelector(".more");

      // 切换文本显示状态
      if (moreText.style.display === "none" || !moreText.style.display) {
        moreText.style.display = "inline";
        this.textContent = "收起"; // 更改按钮的文本
      } else {
        moreText.style.display = "none";
        this.textContent = "顯示詳細資料"; // 恢复按钮的文本
      }
    });
  });
 });
 const container = document.querySelector('.nav');
 const prevButton = document.querySelector('.scroll-button.prev');
 const nextButton = document.querySelector('.scroll-button.next');

 let isDown = false;
 let startX;
  let scrollLeft;

 prevButton.addEventListener('click', () => {
  container.scrollTo({
    left: container.scrollLeft - 200, // 調整滾動距離
    behavior: 'smooth' // 平滑滾動效果
  });
 });

 nextButton.addEventListener('click', () => {
  container.scrollTo({
    left: container.scrollLeft + 200, // 調整滾動距離
    behavior: 'smooth' // 平滑滾動效果
  });
 });

 container.addEventListener('mousedown', (e) => {
  isDown = true;
  startX = e.pageX - container.offsetLeft;
  scrollLeft = container.scrollLeft;
  container.classList.add('active');
 });

 container.addEventListener('touchstart', (e) => {
  const touch = e.touches[0];
  isDown = true;
  startX = touch.pageX - container.offsetLeft;
  scrollLeft = container.scrollLeft;
  container.classList.add('active');
 });

 container.addEventListener('mouseleave', () => {
  isDown = false;
  container.classList.remove('active');
 });

 container.addEventListener('mouseup', () => {
  isDown = false;
  container.classList.remove('active');
 });

 container.addEventListener('touchend', () => {
  isDown = false;
  container.classList.remove('active');
 });

 container.addEventListener('mousemove', (e) => {
  if (!isDown) return;
  e.preventDefault();
  const x = e.pageX - container.offsetLeft;
  const walk = (x - startX) * 2; // 調整拖動速度
  container.scrollLeft = scrollLeft - walk;
 });

 container.addEventListener('touchmove', (e) => {
  if (!isDown) return;
  e.preventDefault();
  const touch = e.touches[0];
  const x = touch.pageX - container.offsetLeft;
  const walk = (x - startX) * 2; // 調整拖動速度
  container.scrollLeft = scrollLeft - walk;
 });



</script>


</body>
<!--隱藏加載-->
</html>