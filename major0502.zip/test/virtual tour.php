<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>桃園客家文化館導覽網站</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="loading.js"></script>
    <link rel="stylesheet" href ="CSS/virtual tour.css?v=<?=time()?>">
	  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> <!--icon連結的css-->
</head>
<body>
<header>
        <button class="menu" id="mobile-menu">&#9776;</button>
        <a href ="index.php" class="title1">桃園客家文化館導覽網站</a>
        <nav class="navbar">
            <ul class="menu-list"> 
                <li><a href="index.php"><span>回首頁</span></a></li>
                <li><a href="virtual tour.php"><span>虛擬導覽</span></a></li>
                <li><a href="Search.php"><span>音樂作品查詢</span></a></li>
                <li><a href="#"><span>問卷回饋</span></a></li>
            </ul>
        </nav>
</header>
        <div class="big" ></div>
        <div class="container">
        <div class="virtual-tour">
            <!-- 在这里嵌入您的虚拟导航内容 -->
            <iframe src="http://120.105.97.29:25218/" frameborder="0" scrolling="no"></iframe>
			<h1>圖<br>片<br>皆<br>可<br>放<br>大</h1>
        </div>
        </div>
        <div class="content">
            <!-- 这里放置您网页的其他内容 -->
        </div>
    </div>
       
	
    <footer class="footer1">
        Pitohui © All Rights Reserved. | Designed by GGlisten X Cadiis
    </footer>
    <script>
  $(function() {
    function checkWindowSize() {
      if ($(window).width() < 768) {
        $('.menu-list').css('max-height', '0');
        $('#mobile-menu').off('click').on('click', function () {
          // 切換 max-height 的值來實現過渡效果
          $('.menu-list').css('max-height', function() {
            return $(this).css('max-height') === '0px' ? $(this).prop('scrollHeight') + 'px' : '0';
          });
        });
      } else {
        $('.menu-list').css('max-height', 'none'); // 移除 max-height，讓內容自動撐開
        // 可能需要處理其他邏輯
      }
    }

    // 初始檢查
    checkWindowSize();

    // 視窗大小改變時重新檢查
    $(window).resize(checkWindowSize);
  });
</script>
</body>
<!--隱藏加載-->
</html>