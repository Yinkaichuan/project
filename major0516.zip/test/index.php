<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>桃園客家文化館導覽網站</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href ="CSS/Indexstyle.css?v=<?=time()?>">
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> <!--icon連結的css-->
    <script src="backToTop.js"></script>
    <script src="loading.js"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://campus-xoops.tn.edu.tw/uploads/smooth-scroll.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap-carousel.min.css" rel="stylesheet">

    
</head>
<body style="margin: 0;padding: 0;">
   <!--加載-->
   <div class="loading-color">
     <div class="loading" id="fountainG">
	     <div id="fountainG_1" class="fountainG"></div>
	     <div id="fountainG_2" class="fountainG"></div>
	     <div id="fountainG_3" class="fountainG"></div>
	     <div id="fountainG_4" class="fountainG"></div>
	     <div id="fountainG_5" class="fountainG"></div>
	     <div id="fountainG_6" class="fountainG"></div>
	     <div id="fountainG_7" class="fountainG"></div>
	     <div id="fountainG_8" class="fountainG"></div>
     </div>
    </div>

    <header >
        <button class="menu" id="mobile-menu">&#9776;</button>
        <a href ="index.php" class="title1">桃園客家文化館導覽網站</a>
        <nav class="navbar">
            <ul class="menu-list"> 
                <li><a href="virtual tour.php"><span>虛擬導覽</span></a></li>
                <li><a href="#about"><span>官方資訊</span></a></li>
                <li><a href="Search.php"><span>音樂作品查詢</span></a></li>
                <li><a href="https://forms.gle/ds75sQyKRr7cdiQ17"><span>問卷回饋</span></a></li>
            </ul>
        </nav>
    </header>
    
    <div class="big" ></div>
    


    <section class="news">
    
    <p><a href="virtual tour.php">進入虛擬導覽</a></p>
    </section>



    <section class="slogan" style="height:100%">
    <div class="slogan1" data-aos="fade-right" data-aos-duration="5000" style="border-style:solid">
    <h2>成立沿革&簡介</h2>
    <hr></hr>
    <blockquote cite="#" data-aos="fade-right" data-aos-duration="5000">
      <h1>桃園市客家文化館主體建築於民國94年完工，
      並於97年3月起陸續開放展館供民眾參觀，
      97年9月配合桃園市客家文化節正式全面開放營運。
      客家文化館以客家文學及客家音樂為推廣核心，
      文化館除了結合動靜態展示、客家表演藝術及客家文化意象，
      還透過多元形式推廣客家藝術及文化，
      來展現客家精神，使客家文化永續推廣並向下傳承。</h1>
    </blockquote>
    </div>
    </section>
     
    <a class="gotop" id="backToTopBtn" href="#">
    <img src="https://campus-xoops.tn.edu.tw/uploads/top.png" style="width: 64px; z-index: 100; position: fixed; right: 20px; bottom: 175px;" alt="#" title="點我回到上方">
    </a>

    

    <section class="Map" >
	  <img src="https://github.com/Pitohui000/project01/blob/main/MUSIC.png?raw=true" data-aos="fade-right">

    <div class="info">
    <h1 data-aos="fade-left">網頁上立刻體驗現場點播機音樂，</h1>
    <h2 data-aos="fade-left">了解道地客家音樂文化。</h2>
    <p data-aos="fade-left"><a href="Search.php">進入音樂作品查詢</a></p>
    </div>
    </section>

    <section class="googlemap" id="about" >
      <div class="container">
        <h2 >官方資訊</h2>
        <hr></hr>
        <div class="infos">
          <div class="left" data-aos="flip-left" data-aos-duration="2500"> 
            <b>桃園市客家文化館地址:</b> <span>325桃園市龍潭區中正路三林段500號</span> <b> 電話:03-4096682</b> 
            <b> 營業時間:<span>星期一：休息</span>
			      <span>星期二～日：09:00–17:00</span></b> 
            <b>官方連結:
             <span><a href="https://www.facebook.com/tychakka/" class="fb" >fb粉絲團</a> <a href="https://www.hakka.tycg.gov.tw/" class="of">事務局網站</a></span> </b> 
          </div>
          <div class="right" data-aos="flip-right" data-aos-duration="2500"> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1810.2604679304209!2d121.23186715142786!3d24.84605159189432!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x34683da78b0cffcf%3A0xe2a2cbcf1cebbd89!2z5qGD5ZyS5biC5a6i5a625paH5YyW6aSo!5e0!3m2!1szh-TW!2stw!4v1698993887372!5m2!1szh-TW!2stw" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> </div>
        </div>
      </div>
    </section>

    
    </main>
    <footer class="footer">
        Pitohui © All Rights Reserved. | Designed by GGlisten X Cadiis
    </footer>
<script>
  AOS.init({
    duration:3000
  });
  $(function() {
    function checkWindowSize() {
      if ($(window).width() < 900) {
        $('.menu-list').css('max-height', '0');
        $('#mobile-menu').off('click').on('click', function () {
          // 切換 max-height 的值來實現過渡效果
          $('.menu-list').css('max-height', function() {
            return $(this).css('max-height') === '0px' ? $(this).prop('scrollHeight') + 'px' : '0';
          });
        });
      } else {
        $('.menu-list').css('max-height', 'none'); // 移除 max-height，讓內容自動撐開
       
      }
    }
    // 初始檢查
    checkWindowSize();

    // 視窗大小改變時重新檢查
    $(window).resize(checkWindowSize);
  });
</script>

</body>

</html>